import { contextBridge, shell } from "electron";

contextBridge.exposeInMainWorld("shell", {
  openDownloadLink: (webContentLink) => shell.openExternal(webContentLink),
});
