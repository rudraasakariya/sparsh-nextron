export const clients = {
  name: "",
  email: "",
  profileURL: "",
  access_token: "",
  expiry_date: "",
  id_token: "",
  profileURL: "",
  refresh_token: "",
  scope: "",
  token_type: "",
};

export const userData = {
  file_1: {
    id: "",
    time: "",
  },
  file_2: {
    id: "",
    time: "",
  },
  file_3: {
    id: "",
    time: "",
  },
  text: "",
};

export const sharedData = {
  send: [
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      to: "",
      permission: "",
    },
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      to: "",
      permission: "",
    },
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      to: "",
      permission: "",
    },
  ],
  receive: [
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      from: "",
      permission: "",
    },
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      from: "",
      permission: "",
    },
    {
      id: "",
      name: "",
      webContenLink: "",
      webViewLink: "",
      time: "",
      from: "",
      permission: "",
    },
  ],
};

export const friendList = [];
