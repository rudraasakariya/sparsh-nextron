const serviceAccount = {
  type: "service_account",
  project_id: "sparsh-69",
  private_key_id: "87ddbdef6f5520b99a2dcca2e1b232600ce42248",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDqoLzfLq5ToDM0\nQniZTatA/xSr6uE16fuazR0aol6acGOp1bWqHSauA4vBnjQOetVO+3CqktvtkRjM\nKFUObv/uy6TGRAjUdIegimkoTxTXBc8Qzp2sYcxqKT1FGo3DWd1MpEBxEivRaba3\nquJR3yGJM5BUUpg3P+qHqHQzFNdshLvHnwVj12HE7/8/FNcMB1CiAQF/ePHFWNuX\nQRQP3brEmpV7sKU7giNVKhCv6bEYoVkhvJr21/rjbMtnSKVOaliuLkjgE/p3zgO1\nlf/X5mn9XzdMb3ujJUGJ/WsqCTEb/hdwSp9xKw3yEVQAnpJ68VvkGwVKvU7ZJnQO\nUZkj0T+vAgMBAAECggEAMsVciXj6/RqV6fGWUiol7DcmXHtDh5ydtuY6rYhEK2w1\njMszd9+9/nrC879NqXJ4FRLA0xBbaeFzeb4ihbCMTjqf6c1QEdUzghBhZ/kQ2+Sk\nZZEoOmShTLmmyfzQf1zDT/HdBfq2I6caBE2Eks3TXnKbgTusN4xrrjZMCr+wTAlU\nxeNuavLCXtG4k0hdUT01rRoIYyPIU0oCx7WOfO+qj8PQr+R2gJkB3oD+mDHrYYAv\ngcLUpYtVxRs3QbJ+Quh+kAuQmpI7JiTjAQuv3fbywziWKb1uEDxwrDSv9lk4K+xm\n72KodO2/OxgRs/D1b0tt/ymcfWlkfz/yodEVSpsxfQKBgQD/kpdbWyGqHzUJx+Ut\nS1Fnq49GxWZcgtQrnvl7X8IdR2NELbVYTKfznq/OmUz6RBSkBKh6r68u6W8y/WBz\nmGH74k+htHIeTSNBy3Vt8ho6uXfOUmanpxFYuOP43PHUhdVGVNhzodtSU8/taL3M\nfvitsgahXnOI6W9psGnbu/wAFQKBgQDrBS4lFeS1jU4CggJenqokT52mPC1Txqss\nHcj11bKeGqf2A3PaAX/f18kPnxUppkOP2MrBtRp+gj64JB+q8q6FD1g6epD1rQtw\njDyo8BlzZfYPpFwIJquwjlsWok9bjhbJJncAuAe2efBoEHXbADmba5KDxAj4IrP2\n/hneEROtswKBgQDkyilfKjT349oKOH3sT2m/ofCwjVS2apRfvIBgtvfCWD8AMN8P\n/ge4aw29qLUlsb68mkLtGct89pKKlhM7SGYnJJDfFPe4MpvmcapdU4exnIkpFdE6\nMrCvuUy0Y67F701fGeNvmK0LhWY1hTesEtqyPBX9bd2F6lvHxJrvj9jnhQKBgEzh\nufG50sKtggqB+0J2xxPv05Ow9ecFA7P/3mDFUpQ0BiQNhxWXDfzs+0IX+XVRhaKF\n+fYaR5uBAgF9F7r1fq/akDM5KzijLi3YQnPFb533ieIeE1k7RUkRmKyz1iAOQFf3\nNFDQ4v0HsORqFhPZY/761sgyFfkOaS7wewfRME3PAoGATqOyS3gpvY4LA6vpIgvy\nxaJs081T0lovJ1wBWfJ5uiZTXjTFdCxLpJ1IKxn30JilCTe+jub9r/1eLwDYWFzU\nCrnogOE41ih6xWbSD+b14DgCLqCPgIQFY0p3T4Im2NTsrBFqahEhS1vBuLIjmejO\nWXzXYLZAHWNY+sWRv9Czp3Q=\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-r4yao@sparsh-69.iam.gserviceaccount.com",
  client_id: "112182053006238873802",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-r4yao%40sparsh-69.iam.gserviceaccount.com",
};


export default serviceAccount;
